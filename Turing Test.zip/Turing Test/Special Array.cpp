#include <iostream>
#include <vector>

bool isSpecialArray(const std::vector<int>& arr) {
    for (size_t i = 0; i < arr.size(); ++i) {
        // Check if the array can be divided into two parts
        bool leftIncreasing = true;
        bool rightDecreasing = true;

        // Check the left part
        for (size_t j = 0; j < i; ++j) {
            if (arr[j] >= arr[j + 1]) {
                leftIncreasing = false;
                break;
            }
        }

        // Check the right part
        for (size_t j = i; j < arr.size() - 1; ++j) {
            if (arr[j] <= arr[j + 1]) {
                rightDecreasing = false;
                break;
            }
        }

        // If both conditions are met, the array is special
        if (leftIncreasing && rightDecreasing) {
            return true;
        }
    }

    // If no partition found, the array is not special
    return false;
}

int main() {
    // Example usage
    std::vector<int> arr1 = {5, 4};
    std::vector<int> arr2 = {2, 5, 6};
    std::vector<int> arr3 = {0, 2, 3, 2, 1};

    std::cout << std::boolalpha;  // to print bool as true/false

    // Test cases
    std::cout << "Test 1: " << isSpecialArray(arr1) << std::endl;  // Output: false
    std::cout << "Test 2: " << isSpecialArray(arr2) << std::endl;  // Output: false
    std::cout << "Test 3: " << isSpecialArray(arr3) << std::endl;  // Output: true

    return 0;
}
